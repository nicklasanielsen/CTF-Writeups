#!/usr/bin/python3
from datetime import datetime, timezone, timedelta
from art import text2art, decor
import asyncio
import socket
import sys
import os
import aiohttp

ELASTIC_HOST = os.getenv('ELASTIC_HOST','elasticsearch') + ":" + str(int(os.getenv('ELASTIC_PORT',9200)))
KIBANA_HOST = os.getenv('KIBANA_HOST','kibana') + ":" + str(int(os.getenv('KIBANA_PORT',5601)))
LOGSTASH_HOST = os.getenv('LOGSTASH_HOST','logstash')
ELASTIC_USER = os.getenv('ELASTIC_USER','elastic')
ELASTIC_PASSWORD = os.getenv('ELASTIC_PASSWORD', '')
SYSLOG_PORT = int(os.getenv('LOGSTASH_SYSLOG_PORT', 1514))
BATCH_SIZE = int(os.getenv('BATCH_SIZE', 1000))
MAX_CONCURRENT_SENDS = int(os.getenv('MAX_CONCURRENT_SENDS', 10))
MAX_UDP_SIZE = 8192
MAX_ATTEMPTS = 10
RETRY_DELAY = 15

a = 60 * decor("tree1", "reverse")
print(a[1:60] + "\n" + a[1:60] + text2art("\n\n ELF   STACK\n is   booting...\n\n") + f"\t****READY AT APPROXIMATELY: {(datetime.now(timezone.utc) + timedelta(minutes=31)).replace(second=0,microsecond=0)} (~20-30 MINUTES)****\n\n" + a[1:60] + "\n" + a[1:60])

async def check_service(url, service_name):
    async with aiohttp.ClientSession() as session:
        for attempt in range(MAX_ATTEMPTS):
            try:
                async with session.get(url, auth=aiohttp.BasicAuth(ELASTIC_USER, ELASTIC_PASSWORD)) as response:
                    if response.status == 200:
                        print(f"[{datetime.now(timezone.utc).isoformat()}] INFO: {service_name} is up!")
                        return True
            except Exception as e:
                print(f"[{datetime.now(timezone.utc).isoformat()}] INFO: The {service_name} connection is not available yet...")
            print(f"[{datetime.now(timezone.utc).isoformat()}] INFO: Retrying connection to {service_name} in {RETRY_DELAY} seconds...")
            await asyncio.sleep(RETRY_DELAY)
    print(f"[{datetime.now(timezone.utc).isoformat()}] ERROR: Connection to {service_name} failed after {MAX_ATTEMPTS} attempts.")
    return False

async def create_kibana_data_view():
    async with aiohttp.ClientSession() as session:
        for attempt in range(MAX_ATTEMPTS):
            try:
                async with session.post(
                    f"http://{KIBANA_HOST}/api/data_views/data_view",
                    auth=aiohttp.BasicAuth(ELASTIC_USER, ELASTIC_PASSWORD),
                    headers={"kbn-xsrf": "true"},
                    json={"data_view": {"name": "Elf Stack", "title": ".ds-logs-*", "timeFieldName": "@timestamp"}}
                ) as response:
                    if response.status == 200:
                        print(f"[{datetime.now(timezone.utc).isoformat()}] INFO: Data View created successfully!")
                        return True
            except Exception as e:
                print(f"[{datetime.now(timezone.utc).isoformat()}] ERROR: Error creating Data View: {e}")
            print(f"[{datetime.now(timezone.utc).isoformat()}] WARN: Failed to create Data View, retrying...")
            await asyncio.sleep(RETRY_DELAY)
    print(f"[{datetime.now(timezone.utc).isoformat()}] ERROR: Failed to create Data View.")
    return False

async def apply_elasticsearch_settings():
    async with aiohttp.ClientSession() as session:
        for attempt in range(MAX_ATTEMPTS):
            try:
                async with session.put(
                    f"http://{ELASTIC_HOST}/_all/_settings",
                    auth=aiohttp.BasicAuth(ELASTIC_USER, ELASTIC_PASSWORD),
                    json={"index": {"number_of_replicas": 0}}
                ) as replica_response:
                    if replica_response.status == 200:
                        print(f"[{datetime.now(timezone.utc).isoformat()}] INFO: Replica settings applied to all indexes.")
                    else:
                        print(f"[{datetime.now(timezone.utc).isoformat()}] WARN: Failed to apply replica settings: {replica_response.status}")
                async with session.put(
                    f"http://{ELASTIC_HOST}/_all/_settings?preserve_existing=true",
                    auth=aiohttp.BasicAuth(ELASTIC_USER, ELASTIC_PASSWORD),
                    json={"index.mapping.total_fields.limit": "15000"}
                ) as index_response:
                    if index_response.status == 200:
                        print(f"[{datetime.now(timezone.utc).isoformat()}] INFO: Index settings updated successfully.")
                        return True
                    else:
                        print(f"[{datetime.now(timezone.utc).isoformat()}] ERROR: Failed to update index settings: {index_response.status}")
            except Exception as e:
                print(f"[{datetime.now(timezone.utc).isoformat()}] ERROR: Error applying settings with error: {e}")
            print(f"[{datetime.now(timezone.utc).isoformat()}] INFO: Retrying settings in {RETRY_DELAY} seconds...")
            await asyncio.sleep(RETRY_DELAY)
    print(f"[{datetime.now(timezone.utc).isoformat()}] ERROR: Failed to apply Elasticsearch settings.")
    return False

async def send_syslog_message(sock, message, server_address, syslog_port):
    if len(message) > MAX_UDP_SIZE:
        print(f"[{datetime.now(timezone.utc).isoformat()}] WARN: UDP message size exceeds MAX_UDP_SIZE ({len(message)} bytes)")
    sock.sendto(message.encode('utf-8'), (server_address, syslog_port))
    await asyncio.sleep(0.001)

async def send_syslog_messages(file_path, server_address, syslog_port):
    print(f"[{datetime.now(timezone.utc).isoformat()}] INFO: Starting log ingestion for file: {file_path}")
    udp_sockets = [socket.socket(socket.AF_INET, socket.SOCK_DGRAM) for _ in range(MAX_CONCURRENT_SENDS)]
    for sock in udp_sockets:
        sock.setblocking(False)
    semaphore = asyncio.Semaphore(MAX_CONCURRENT_SENDS)
    total_lines = 0
    try:
        with open(file_path, 'r') as file:
            batch = []
            for line in file:
                if not line.endswith('\n'):
                    line += '\n'
                batch.append(line)
                if len(batch) >= BATCH_SIZE:
                    await process_batch(batch, udp_sockets, semaphore, server_address, syslog_port)
                    total_lines += len(batch)
                    batch.clear()
            if batch:
                await process_batch(batch, udp_sockets, semaphore, server_address, syslog_port)
                total_lines += len(batch)
    except FileNotFoundError:
        print(f"[{datetime.now(timezone.utc).isoformat()}] ERROR: File {file_path} not found.")
    except Exception as e:
        print(f"[{datetime.now(timezone.utc).isoformat()}] ERROR: Processing file {file_path} with error: {e}")
    finally:
        for sock in udp_sockets:
            sock.close()
    return total_lines

async def process_batch(batch, udp_sockets, semaphore, server_address, syslog_port):
    tasks = []
    for i, line in enumerate(batch):
        sock = udp_sockets[i % MAX_CONCURRENT_SENDS]
        await semaphore.acquire()
        task = asyncio.create_task(send_syslog_message(sock, line, server_address, syslog_port))
        task.add_done_callback(lambda _f: semaphore.release())
        tasks.append(task)
    await asyncio.gather(*tasks)

async def main():
    if len(sys.argv) < 2:
        print("Usage: python3 syslog-sender.py <log_file_path1> <log_file_path2> ...")
        sys.exit(1)
    log_files = sys.argv[1:]
    total_lines_sent = 0
    overall_start_time = datetime.now()
    services = [
        (f"http://{ELASTIC_HOST}", "Elasticsearch"),
        (f"http://{LOGSTASH_HOST}:9600/_node/pipelines", "Logstash"),
        (f"http://{KIBANA_HOST}/api/status", "Kibana")
    ]
    for url, name in services:
        if not await check_service(url, name):
            sys.exit(1)
    await asyncio.sleep(RETRY_DELAY - 5)
    if not await apply_elasticsearch_settings():
        sys.exit(1)
    if not await create_kibana_data_view():
        sys.exit(1)
    async with aiohttp.ClientSession() as session:
        for log_file in log_files:
            if not os.path.exists(log_file):
                print(f"[{datetime.now(timezone.utc).isoformat()}] ERROR: File does not exist - {log_file}")
                continue
            lines_sent = await send_syslog_messages(log_file, LOGSTASH_HOST, SYSLOG_PORT)
            total_lines_sent += lines_sent
    print(f"[{datetime.now(timezone.utc).isoformat()}] INFO: Total number of lines sent across all log files: {total_lines_sent}.")
    print(f"[{datetime.now(timezone.utc).isoformat()}] INFO: Total time taken for ingestion: {str(datetime.now() - overall_start_time).split('.')[0]}.")
    print(a[1:60] + "\n" + a[1:60] + text2art("\n ELF   STACK\n is   ready!\n\n") + "*"*40 + f"\n\tLOGIN INFORMATION:\n\t\tURL: http://localhost:5601\n\t\tUsername: {ELASTIC_USER}\n\t\tPassword: {ELASTIC_PASSWORD}\n\n\t\tSET DATE IN ANALYSIS: DISCOVER TO 2024\n" + "*"*40 + "\n\n" + a[1:60] + "\n" + a[1:60])

if __name__ == '__main__':
    asyncio.run(main())
